from kyt import *
import subprocess
import time

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def ganti_ip(event):
    async def ganti_ip_(event):
        chat = event.chat_id  # Definisikan variabel chat di sini
        sender = await event.get_sender()
        
        # Meminta Username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Masukkan Username:**')
            user_event = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_event.raw_text.strip()

        # Meminta IPvps
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Masukkan IPvps:**")
            pw_event = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw_event.raw_text.strip()
            
        # Meminta Durasi
        async with bot.conversation(chat) as day_conv:
            await event.respond("**Masukkan jumlah hari:**")
            day_event = await day_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            day = day_event.raw_text.strip()

        # Meminta Token GitHub
        async with bot.conversation(chat) as token_conv:
            await event.respond("**Masukkan Personal Access Token GitHub:**")
            token_event = await token_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            token = token_event.raw_text.strip()
        
        # Validasi Input
        if not user or not pw or not day.isdigit() or not token:
            await event.respond("**Input tidak valid. Pastikan semua field terisi dengan benar.**")
            return
        
        # Proses Registrasi
        await event.edit("Processing.")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 50%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        # Menjalankan Script Bash
        cmd = f'printf "%s\n" "{pw}" "{user}" "{day}" "{token}" | bash /root/usr/bin/add-ip'
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                check=True,
                capture_output=True,
                text=True
            )
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🍀 VPS SUCCESSFULLY REGISTER 🍀**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🌹 NAME AUTHOR : {user}**
**🏵️ SCRIPT TIME : {day} day**
**🌺 IP SERVER   : {pw}**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
        except subprocess.CalledProcessError as e:
            await event.respond(f"**Error:** {e.stderr.strip()}")

    # Validasi Pengguna
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await ganti_ip_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
